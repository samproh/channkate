<template>
  <div
    class="w-full max-w-md p-4 bg-white border rounded-lg shadow-md sm:p-8 mx-auto mt-7"
  >
    <div class="flex items-center justify-between mb-4">
      <h5 class="text-xl font-bold leading-none text-gray-900">
        Big Thanks to
      </h5>
    </div>
    <div class="flow-root">
      <ul role="list" class="divide-y divide-gray-200">
        <li class="py-3 sm:py-4">
          <div class="flex items-center space-x-4">
            <div class="flex-shrink-0">
              <div class="w-10 h-10">
                <img
                  src="https://avatars.githubusercontent.com/u/20786386?v=4"
                  alt="ThyrithSor"
                  class="object-contain w-full h-full"
                />
              </div>
            </div>
            <div class="flex-1 min-w-0">
              <p class="text-sm font-medium text-gray-900 truncate">
                ThyrithSor/momentkh
              </p>
              <a
                href="https://github.com/ThyrithSor/momentkh"
                target="_blank"
                class="text-sm text-gray-500 truncate"
              >
                https://github.com/ThyrithSor/momentkh
              </a>
            </div>
          </div>
        </li>
        <li class="py-3 sm:py-4">
          <div class="flex items-center space-x-4">
            <div class="flex-shrink-0">
              <div class="w-10 h-10">
                <img
                  src="https://avatars.githubusercontent.com/u/67109815?s=200&v=4"
                  alt="Tailwind CSS"
                  class="object-contain w-full h-full"
                />
              </div>
            </div>
            <div class="flex-1 min-w-0">
              <p class="text-sm font-medium text-gray-900 truncate">
                Tailwind CSS
              </p>
              <a
                href="https://tailwindcss.com/"
                target="_blank"
                class="text-sm text-gray-500 truncate"
              >
                https://tailwindcss.com/
              </a>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
