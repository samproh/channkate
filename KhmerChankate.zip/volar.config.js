const vetur = require('@volar-plugins/vetur');

module.exports = {
    plugins: [
        vetur(),
    ],
};